<?php
require_once(dirname(__FILE__).'/mh_class_register_post.php');
require_once(dirname(__FILE__).'/mh_class_update_post.php');
require_once(dirname(__FILE__).'/mh_template_loader.php');
