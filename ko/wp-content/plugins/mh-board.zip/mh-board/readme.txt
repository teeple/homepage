=== Plugin Name ===
Contributors: ssamture
Donate link: http://ssamture.net/donate
Tags: board, 게시판, 한국형 게시판, forum, community, 커뮤니티
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 1.1


MH Board is bulletin board for WordPress.

MH Board available to the community. It’s on your site will create a new space of communication.

Will be continually updated to provide new features

== Description ==

MH Board is bulletin board for your WordPress.
MH Board available to the community. It’s on your site will create a new space of communication.
Will be continually updated to provide new features

* [Docs(Korean)](http://ssamture.net/archives/2638)
* [FAQ(Korean)](http://ssamture.net/board/board_cat/faq)
* [Support(Korean)](http://ssamture.net/community/)
* [Support(English)](http://en.ssamture.net)

== Installation ==

1. Place the 'mh-board' folder in your '/wp-content/plugins/' directory.
2. Activate MH Board.
3. Visit 'MH Board' and adjust your configuration.
4. Create menu for MH Board.
5. Visit your site.
6. Adjust the CSS of your theme as needed.

== Screenshots ==

1. screenshot 1
2. screenshot 2
3. screenshot 3
4. screenshot 4

== Changelog ==

= 1.2.7 =
* Bugfix : ShortCode bugfix.

= 1.2.6 =
* Update : Security patch
* Bugfix : Edit bugfix.

= 1.2.5 =
* Update : Security(File upload)
* Upgrade : Post Algorithm

= 1.2.4 =
* Bugfix : Shortcode
= 1.2.3 =
* Upgrade : Permission improvement.

= 1.2.2 =
* Bugfix : Comment bugfix.

= 1.2.1 =
* Bugfix : Permission Bugfix.
* New : Add email column in admin
* New : Write textarea background

= 1.2 =
* Bugfix : Permission Bugfix.
* Change : If wrting in the category list, category select box hide.
* Change : Category select box hide in the Edit view.
* New : add list button.
* New : add cancel button.

= 1.1 =
* New : add permission.게시판 권한 기능 추가
* New : Default Category setting. 글 쓰기 시 기본 카테고리 지정 추가
* New : Reply comment.
* New : add function for devloper.  get_recent_mh_board('board_cat slug', 'count');

= 1.0 =
* Change : Add & edit core change
* Upgrade : shortcode
* Change : Layout change
* New : add language (English, Korean) 
* Bugfix : paging error
* New : MH Board Custom CSS
* Bugfix : Etc.

= 0.9.6 = 
* Bugfix : function optimize

= 0.9.5 =
* New : attachment

= 0.9.4 =
* Bugfix : add & edit link
* New : If you are an administrator, a private Posts Comments can be registered to add
* New : permalink for MH Board

= 0.9.3 =
* Bugfix :  limit loading

= 0.9.2 =
* Bugfix.

= 0.9.1 =
* Bugfix.

= 0.9.0 =
* New :  Button style
* New : support responsive web
* New : Shortcode to generate support 

= 0.8.0 =
* New :  Category display/hide
* New : Reply display/hide
* New : Private article did not go to the dashboard so that the administrator can change.

= 0.7.3 =
* Bugfix :  Admin panel, the entire board was missing bug fixes.

= 0.7.1 =
* Bugfix :  Link using the default permalink bug fixes

= 0.7.0 =
* New :  Add nonmembers writing permission set.
* New : Writing strengthening security.
* New : Add editor.

= 0.6.2 =
* New : Automatic link. 
* New : Link re-create when modify the permalink.
* Bugfix : Non category error.
* Bugfix.

= 0.6.2 =
First released.
== Upgrade Notice ==

